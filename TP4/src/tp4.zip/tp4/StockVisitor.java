package tp4;

public interface StockVisitor {

	void visitiAnimal (Animal animal);
	void visitNourriture ( Nourriture nourriture);
	
}
